package com.main.adminpj.dao;

import com.main.adminpj.model.User;

import java.util.List;

public interface UserDao {
    public List<User> getAllUsers();
//    public List<payment_system> getAllpaymentSystem();
//    public List<luggage> getAllLugage();
//    public List<bookinglist> getAllticket();;
//    public List<flight> getAllFlight();

}
