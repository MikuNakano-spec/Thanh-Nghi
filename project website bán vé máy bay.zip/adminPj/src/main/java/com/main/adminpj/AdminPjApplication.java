package com.main.adminpj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdminPjApplication {

    public static void main(String[] args) {
        SpringApplication.run(AdminPjApplication.class, args);
    }

}
